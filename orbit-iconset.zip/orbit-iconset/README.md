# Orbit — иконка приложения (альтернатива Syncthing)

Минималистичный знак: кольцо-орбита с двумя узлами = два пира, удерживаемые в синхроне.
Все формы векторные, читаются от 16 px, переживают любую маску ОС.

## Темизация под Material 3 Expressive
`svg/orbit-master-themeable.svg` использует две CSS-переменные:
    --container      — цвет плитки (роль primary / primaryContainer)
    --on-container   — цвет знака (роль onPrimary / onPrimaryContainer)
Подставь любую динамическую пару M3 — иконка перекрасится целиком.

## Что внутри
svg/
  orbit-master-themeable.svg  основной мастер (с переменными)
  orbit-graphite.svg          плитка по умолчанию (graphite)
  orbit-graphite-fullbleed.svg full-bleed (без скругления) — для App Store / Play
  orbit-foreground.svg        только знак, прозрачный фон — Android adaptive / tray / favicon
  orbit-light.svg / orbit-dark.svg   светлая и тёмная плитка
  orbit-blue / teal / violet.svg     примеры палитр M3
png/
  orbit-16…1024.png           растровые размеры (graphite, скруглённые)
  orbit-1024-fullbleed.png    full-bleed
  orbit-1024-foreground.png   прозрачный знак

## Flutter
Для генерации иконок удобно flutter_launcher_icons:
    image_path: "png/orbit-1024.png"
    adaptive_icon_foreground: "png/orbit-1024-foreground.png"
    adaptive_icon_background: "#3A3C41"
Векторный мастер оставь в ассетах для in-app логотипа (масштабируется без потерь).
